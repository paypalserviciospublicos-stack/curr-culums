export type CVWord = {
  nombre: string; titulo: string; email: string; telefono: string; ciudad: string; perfil: string;
  foto: string | null;
  experiencia: { puesto: string; empresa: string; periodo: string; detalle: string }[];
  educacion: { titulo: string; institucion: string; periodo: string }[];
  habilidades: string; idiomas: string;
};

export async function generarWord(d: CVWord, conFoto: boolean): Promise<Blob> {
  const { Document, Packer, Paragraph, TextRun, ImageRun, BorderStyle, AlignmentType } = await import("docx");
  const font = "Arial";
  const h = (t: string) => new Paragraph({
    spacing: { before: 240, after: 80 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "333333", space: 1 } },
    children: [new TextRun({ text: t.toUpperCase(), bold: true, size: 24, font })],
  });
  const p = (t: string, opts: { bold?: boolean; italic?: boolean } = {}) =>
    new Paragraph({ spacing: { after: 40 }, children: [new TextRun({ text: t, size: 21, font, ...opts })] });
  const lines = (t: string) => t.split("\n").map((l) => l.trim()).filter(Boolean).map((l) => p(l));
  const list = (s: string) => s.split(",").map((x) => x.trim()).filter(Boolean);

  const children: InstanceType<typeof Paragraph>[] = [];
  if (conFoto && d.foto) {
    try {
      const bin = atob(d.foto.split(",")[1] ?? "");
      const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
      const type = d.foto.includes("image/png") ? "png" : "jpg";
      children.push(new Paragraph({ children: [new ImageRun({ type, data: bytes, transformation: { width: 100, height: 100 }, altText: { title: "Foto", description: "Foto", name: "Foto" } })] }));
    } catch { /* ignorar foto inválida */ }
  }
  children.push(new Paragraph({ children: [new TextRun({ text: d.nombre || "Tu Nombre", bold: true, size: 40, font })] }));
  if (d.titulo) children.push(p(d.titulo, { bold: true }));
  const contacto = [d.email, d.telefono, d.ciudad].filter(Boolean).join(" | ");
  if (contacto) children.push(p(contacto));
  if (d.perfil) { children.push(h("Resumen profesional"), ...lines(d.perfil)); }
  const exps = d.experiencia.filter((x) => x.puesto || x.empresa);
  if (exps.length) {
    children.push(h("Experiencia laboral"));
    exps.forEach((x) => {
      children.push(p(x.puesto, { bold: true }));
      const sub = [x.empresa, x.periodo].filter(Boolean).join(" | ");
      if (sub) children.push(p(sub, { italic: true }));
      children.push(...lines(x.detalle));
    });
  }
  const edus = d.educacion.filter((x) => x.titulo || x.institucion);
  if (edus.length) {
    children.push(h("Educación"));
    edus.forEach((x) => { children.push(p(x.titulo, { bold: true })); const s = [x.institucion, x.periodo].filter(Boolean).join(" | "); if (s) children.push(p(s)); });
  }
  if (list(d.habilidades).length) children.push(h("Habilidades"), p(list(d.habilidades).join(", ")));
  if (list(d.idiomas).length) children.push(h("Idiomas"), p(list(d.idiomas).join(", ")));

  const doc = new Document({
    sections: [{
      properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1000, right: 1100, bottom: 1000, left: 1100 } } },
      children: children.map((c) => c),
    }],
  });
  void AlignmentType;
  return Packer.toBlob(doc);
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}
